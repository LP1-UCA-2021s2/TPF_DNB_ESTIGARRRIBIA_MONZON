/*
 ============================================================================
 Name        : GTKTablero.c
 Author      : Jorge Estigarribia, Martin Monzon
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in GTK+
 ============================================================================
 */
#include <gtk/gtk.h>
#include "funciones.h"
#include <string.h>
GtkBuilder *builder;
GError *error = NULL;
gboolean  block=FALSE;

//play
void isClickedplay()
{
	gtk_widget_show_all(w_play);
	gtk_widget_hide(w_main);
}
void isClickedbackplay()
{
	gtk_widget_show_all(w_main);
	gtk_widget_hide(w_play);
}
//credits
void isClickedcredits()
{
	gtk_widget_show_all(w_credits);
	gtk_widget_hide(w_main);
}
void isClickedbackcred()
{
	gtk_widget_show_all(w_main);
	gtk_widget_hide(w_credits);
}
//rules
void isClickedrules()
{
	gtk_widget_show_all(w_rules);
	gtk_widget_hide(w_main);
}
void isClickedbackrules()
{
	gtk_widget_show_all(w_main);
	gtk_widget_hide(w_rules);
}
//quit
void isClickedquit()
{
	exit(1);
}
//players
/*void isClickedpvp()
{
	gtk_widget_show_all(w_tam);
	gtk_widget_hide(w_play);
	cantjug=0;
}*/
void isClickedpvc()
{
	gtk_widget_show_all(w_tam);
	gtk_widget_hide(w_play);
	cantjug=1;
}
void isClickedcvc()
{
	gtk_widget_show_all(w_tam);
	gtk_widget_hide(w_play);
	cantjug=2;
}
void isClickedbackplayers()
{
	gtk_widget_show_all(w_play);
	gtk_widget_hide(w_tam);
}
//tam
/*void isClickedtam3()
{
	//SIZE=3;
	//TAM_REAL=SIZE*2-1;
	//CreateBoard();
	//gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}*/

/*void isClickedtam4()
{
	SIZE=4;
	TAM_REAL=SIZE*2-1;
	int i;
	board=(int**)malloc(TAM_REAL * sizeof(int*));
	for(i=0; i<TAM_REAL; i++)
		board[i]=(int*)malloc(TAM_REAL * sizeof(int));
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam5()
{
	SIZE=5;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam6()
{
	SIZE=6;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam7()
{
	SIZE=7;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam8()
{
	SIZE=8;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam9()
{
	SIZE=9;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam10()
{
	SIZE=10;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam11()
{
	SIZE=11;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam12()
{
	SIZE=12;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam13()
{
	SIZE=13;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam14()
{
	SIZE=14;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtam15()
{
	SIZE=15;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}
void isClickedtamR()
{
	SIZE= 3 + rand() % 13;
	TAM_REAL=SIZE*2-1;
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}*/


void isClickedbacktam()
{
	gtk_widget_show_all(w_tam);
	gtk_widget_hide(w_nom);
}
//turno
void isClickedturno()
{
	gtk_widget_show_all(w_turn);
	gtk_widget_hide(w_nom);
}

void isClickedbackturno()
{
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_turn);
}
//jugar
void isClickedturno1()
{
	start=1;
	gtk_widget_show_all(w_jugar);
	gtk_widget_hide(w_turn);
}
void isClickedturno2()
{
	start=2;
	gtk_widget_show_all(w_jugar);
	gtk_widget_hide(w_turn);
}
void isClickedturno3()
{
	start=rand() % 2;
		if (start==0){
			start=1;
		}else
		{
			start=2;
		}
	gtk_widget_show_all(w_jugar);
	gtk_widget_hide(w_turn);
}


int** arraymaker(int m)
{
		int len=0;
	    int *ptr, **arr;
	    int i;

	    len = sizeof(int *) * m + sizeof(int) * m * m;
	    arr = (int **)malloc(sizeof(len));

	    ptr = (int *)(arr + m);

	    for(i = 0; i < m; i++)
	        arr[i] = (ptr + m * i);

	    return arr;
}




//Toma el tamanho de la matriz
void matrixSize(GtkWidget *widget, gpointer data)
{
	//neo what is the size?
	//the size is what you believe it is
	inputam[0]="\0";
	MATRIXSZ=gtk_entry_get_text(GTK_ENTRY(entrysize));
	sprintf(inputam,"%s",(char*)MATRIXSZ);
	//Msize=atoi(inputam);
	gtk_widget_show_all(w_nom);
	gtk_widget_hide(w_tam);
}


void CreateBoard()
{
	int i;
	int j;
	//board=(int**)malloc(TAM_REAL * sizeof(int*));

	for(i=0; i<TAM_REAL; i++)
		{
			//board[i]=(int*)malloc(TAM_REAL * sizeof(int));
			for(j=0; j<TAM_REAL; j++)
			{
				if (j%2)
				{
					board[i][j]=0;
				}else{
					board[i][j]=4;
				}
				if (i%2)
				{
					board[i][j]=8;
					if (j%2 ==0)
					{
						board[i][j]=0;
					}
				}
			}
		}
}

void PrintBoard()
{
	int i,j;
	for (i=0; i<TAM_REAL; i++)
	{
		printf("\n");
		for(j=0; j<TAM_REAL; j++)
		printf("%d", board[i][j]);
	}
	printf("\n");
	printf("JUGADOR %d puntos",User);
	printf("\n");
	printf("PC %d puntos",Comp);
	printf("\n");
}

/*char* on_entry1_changed(GtkEntry* a)
{
	char name[100];
	sprintf(name,"%s",gtk_entry_get_text(a));
	return *name;
}*/


void freetab()
{
	int i;
	for(i=0; i<TAM_REAL; i++)
	{
		free(board[i]);
	}
	free(board);
}

void end()
	{
	int i,j;
	//freetab();
	CreateBoard();
	cont=0;
	T=0;
	User=0;
	Comp=0;
	for(i=0; i<TAM_REAL; i++)
		for(j=0; j<TAM_REAL; j++)
			if (i%2==0 && j%2==0){
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)), imagenes[0]);
			}else{
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)), imagenes[1]);
			}
	}

void desp()
{
	block=FALSE;
	char GANO[100],*name;
	//name=on_entry1_changed(entry1);
	gtk_widget_show_all(w_end);
	gtk_widget_set_sensitive(w_jugar,block);
	sprintf(GANO,"PUNTOS\n Player:%d Pc:%d\n",User,Comp);
	gtk_label_set_text(GTK_LABEL(DESP), GANO);
	block=TRUE;
	end();
}



void isClickedmainmenu()
{
	gtk_widget_show_all(w_main);
	gtk_widget_hide(w_jugar);
	gtk_widget_hide(w_end);
	gtk_widget_set_sensitive(w_jugar,block);
}
void chequeo(int i,int j)
{
		char score[100];
		char turno[100];
        if (board[i-1][j-1]==1 && board[i-2][j]==2 && board[i-1][j+1]==1 && board[i][j]==2)//si el ultimo movimineto es abajo
        {

            if (Player==1)
            {
                User+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i-1)), naranja[2]);
                board[i-1][j]=7;
                T=0;
                sprintf(turno,"PUNTO PARA EL JUGADOR");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
            }
            if (Player==0)
            {
                Comp+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i-1)), azul[2]);
                board[i-1][j]=6;
                T=1;
                sprintf(turno,"PUNTO PARA LA PC");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
            }
            printf("\nFelicidades tiene 1 cuadrado \n Player:%d Pc:%d",User,Comp);
            sprintf(score,"   PUNTOS \n Player:%d Pc:%d\n",User,Comp);
            gtk_label_set_text(GTK_LABEL(Jugador1), score);
        }

        if (board[i+1][j-1]==1 && board[i+2][j]==2 && board[i+1][j+1]==1 && board[i][j]==2)           //si el ultimo movimineto es arriba
        {
            if (Player==1)
                {
                User+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i+1)), naranja[2]);
                board[i+1][j]=7;
                T=0;
                sprintf(turno,"PUNTO PARA EL JUGADOR");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
                }
            if (Player==0)
                {
                Comp+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i+1)), azul[2]);
                board[i+1][j]=6;
                T=1;
                sprintf(turno,"PUNTO PARA LA PC");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
                }
            printf("\nFelicidades tiene 1 cuadrado \n Player:%d Pc:%d",User,Comp);
            sprintf(score,"   PUNTOS \n Player:%d Pc:%d\n",User,Comp);
            gtk_label_set_text(GTK_LABEL(Jugador1), score);
        }
        if (board[i][j-2]==1 && board[i-1][j-1]==2 && board[i+1][j-1]==2 && board[i][j]==1)           //si el ultimo movimineto es derecha
        {
            if (Player==1){
                User+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j-1,i)), naranja[2]);
                board[i][j-1]=7;
                T=0;
                sprintf(turno,"PUNTO PARA EL JUGADOR");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
                }
            if (Player==0){
                Comp+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j-1,i)), azul[2]);
                board[i][j-1]=6;
                T=1;
                sprintf(turno,"PUNTO PARA LA PC");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
                }
            printf("\nFelicidades tiene 1 cuadrado \n Player:%d Pc:%d",User,Comp);
            sprintf(score,"   PUNTOS \n Player:%d Pc:%d\n",User,Comp);
            gtk_label_set_text(GTK_LABEL(Jugador1), score);
        }
        if (board[i-1][j+1]==2 && board[i][j+2]==1 && board[i+1][j+1]==2 && board[i][j]==1)           //si el ultimo movimineto es izquierda
        {
            if (Player==1)
            {
                User+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j+1,i)), naranja[2]);
                board[i][j+1]=7;
                T=0;
                sprintf(turno,"PUNTO PARA EL JUGADOR");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
            }
            if (Player==0)
            {
                Comp+=10;
                gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j+1,i)), azul[2]);
                board[i][j+1]=6;
                T=1;
                sprintf(turno,"PUNTO PARA LA PC");
                gtk_label_set_text(GTK_LABEL(Jugador2), turno);
            }
            printf("\nFelicidades tiene 1 cuadrado \n Player:%d Pc:%d",User,Comp);
            sprintf(score,"   PUNTOS \n Player:%d Pc:%d\n",User,Comp);
            gtk_label_set_text(GTK_LABEL(Jugador1), score);
        }
}
void Pc_move()
{
	int i,j;
	int c=0;
	int f=0;
	int t=0;
	//banderas
	int nope=0;
	int oof=0;
	for (i=0;i<TAM_REAL;i++)
	{
		for (j=0;j<TAM_REAL;j++)
		{
			if (i%2!=0 && j%2!=0)
			{
				if (board[i-1][j]!=0 && board[i][j-1]!=0 && board[i+1][j]!=0 && board[i][j+1]==0)//si falta abajo
				{
					j=j+1;
					c=1;
					break;
				}
				if (board[i-1][j]!=0 && board[i+1][j]!=0 && board[i][j+1]!=0 && board[i][j-1]==0)//si falta arriba
				{
					j=j-1;
					c=1;
					break;
				}
				if (board[i][j-1]!=0 && board[i-1][j]!=0 && board[i][j+1]!=0 && board[i+1][j]==0)//si falta derecha
				{
					i=i+1;
					c=1;
					break;
				}
				if (board[i-1][j]==0 && board[i][j-1]!=0 && board[i][j+1]!=0 && board[i+1][j]!=0)//si falta izquierda
				{
					i=i-1;
					c=1;
					break;
				}
			}
		}
		if(c==1)
		{
			nope=1;
			break;
		}
	}

	if(t==1)
	{
		i=rand() % TAM_REAL;
		j=rand() % TAM_REAL;
		while(board[i][j]!=0)
		{
			i=rand() % TAM_REAL;
			j=rand() % TAM_REAL;
		}
		nope=1;
	}
	while (nope==0){
		/////2 marcados
		f++;
		nope=1;
		i=rand() % TAM_REAL;
		//redpilledcoding
		j=rand() % TAM_REAL;
		while(board[i][j]!=0)
		{
			i=rand() % TAM_REAL;
			j=rand() % TAM_REAL;
		}
		if (board[i][j]==0)
		{
			////izquierda
			if (board[i-1][j+1]==2 && board[i][j+2]==0 && board[i+1][j+1]==2 && board[i][j]==0)//arriba abajo
			{
				nope=0;
			}
			if (board[i-1][j+1]==2 && board[i][j+2]==1 && board[i+1][j+1]==0 && board[i][j]==0)//arriba derecha
			{
				nope=0;
			}
			if (board[i-1][j+1]==0 && board[i][j+2]==1 && board[i+1][j+1]==2 && board[i][j]==0)//derecha abajo
			{
				nope=0;
			}
			////derecha
			if (board[i][j-2]==1 && board[i-1][j-1]==0 && board[i+1][j-1]==2 && board[i][j]==0)//abajo izquierda
			{
				nope=0;
			}
			if (board[i][j-2]==1 && board[i-1][j-1]==2 && board[i+1][j-1]==0 && board[i][j]==0)//arriba izquierda
			{
				nope=0;
			}
			if (board[i][j-2]==0 && board[i-1][j-1]==2 && board[i+1][j-1]==2 && board[i][j]==0)//arriba abajo
			{
				nope=0;
			}
			////arriba
			if (board[i+1][j-1]==0 && board[i+2][j]==2 && board[i+1][j+1]==1 && board[i][j]==0)//abajo derecha
			{
				nope=0;
			}
			if (board[i+1][j-1]==1 && board[i+2][j]==2 && board[i+1][j+1]==0 && board[i][j]==0)//abajo izquierda
			{
				nope=0;
			}
			if (board[i+1][j-1]==1 && board[i+2][j]==0 && board[i+1][j+1]==1 && board[i][j]==0)//izquierda derecha
			{
				nope=0;
			}

			////abajo
			if (board[i-1][j-1]==1 && board[i-2][j]==2 && board[i-1][j+1]==0 && board[i][j]==0)//izquierda arriba
			{
				nope=0;
			}
			if (board[i-1][j-1]==0 && board[i-2][j]==2 && board[i-1][j+1]==1 && board[i][j]==0)//arriba derecha
			{
				nope=0;
			}
			if (board[i-1][j-1]==1 && board[i-2][j]==0 && board[i-1][j+1]==1 && board[i][j]==0)//izquierda derecha
			{
				nope=0;
			}
		}
		if (nope==1)
		{
			oof=rand() % 10;
			if (oof==6)
			{
				while(board[i][j]!=0)
				{
					i=rand() % TAM_REAL;
					j=rand() % TAM_REAL;
				}
				nope=0;
				break;
			}
		}
		if (f==1000){
			t=1;
			break;
		}
	}
	if ((i%2!=0 && j%2==0)) {
		gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)), azul[1]);
		board[i][j]=1;
	}
	if ((i%2==0 && j%2!=0)) {
		gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)), azul[0]);
		board[i][j]=2;
	}
	Player=0;
	chequeo(i,j);
}
void GamePlay(GtkWidget *event_box, GdkEventButton *event, gpointer data)
{
		int i,j;
		i = (GUINT_FROM_LE(event->y) / 50);
		j = (GUINT_FROM_LE(event->x) / 50);
		char turno[100];
		if (start==2)
		{
			Pc_move();
			cont++;
			PrintBoard();
			start=1;
			T=0;
			return;
		}
		/*printf("i %d j %d",i,j);
		printf("\n");
		printf("cont %d",cont);
		printf("\n");
		printf("contenido %d",board[i][j]);
		printf("\n");*/
		if (board[i][j]==0)
		{
			if (T==0)
			{
				sprintf(turno," JUEGA JUGADOR");
				printf(" JUEGA JUGADOR");
				gtk_label_set_text(GTK_LABEL(CONTMOV), turno);
				T=1;
				if (i%2!=0 && j%2==0)
				{
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)), naranja[1]);
					board[i][j]=1;
				}
				if (i%2==0 && j%2!=0)
				{
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)), naranja[0]);
					board[i][j]=2;
				}
				Player=1;
				cont++;
				chequeo(i,j);
				PrintBoard();
				printf("----------");
				if(cont>=Jogadas)
				{
					desp();
				}
			}

			if (T==1)
			{
				sprintf(turno,"JUEGA PC ");
				printf("JUEGA PC ");
				gtk_label_set_text(GTK_LABEL(CONTMOV), turno);
				T=0;
				Pc_move();
				cont++;
				PrintBoard();
				printf("-----------");
				if(cont>=Jogadas)
				{
					desp();
				}
			}
		}
}


GtkWidget *crear_tablero()
{
	int i, j;
	GtkWidget *imagen;
	GtkWidget *eventbox;
	eventbox = gtk_event_box_new();
	tablero = gtk_grid_new();
	CreateBoard();
	for(i=0; i<TAM_REAL; i++)
		for(j=0; j<TAM_REAL; j++)
			if (i%2==0 && j%2==0){
				imagen = gtk_image_new_from_file(imagenes[0]);
				gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagen), j, i, 1, 1);
			}else{
				imagen = gtk_image_new_from_file(imagenes[1]);
				gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagen), j, i, 1, 1);
			}
	gtk_container_add(GTK_CONTAINER(eventbox), tablero);
	g_signal_connect(eventbox, "button-press-event", G_CALLBACK(GamePlay), tablero);
	return eventbox;
}

void cerrar (GtkWidget *object, gpointer   user_data){
	 printf("saludo: %s", (char*)user_data);
	 gtk_main_quit();
}

void CantJogadas()
{
	for (int i=0;i<SIZE;i++)
		{
			Jogadas=i*i*4-Jogadas;
		}
}

int main (int argc, char *argv[])
{
	srand(time(NULL));
    gtk_init (&argc, &argv);
    builder = gtk_builder_new();
	if (gtk_builder_add_from_file(builder, "tablero.glade", &error) == 0) {
		g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
		return 1;
	 }
////////////////////////////////////////////////////////////////////////////////////////////
	 //Ventana principal
	 w_main = GTK_WIDGET(gtk_builder_get_object(builder, "PANTPRINC"));
	 g_signal_connect (w_main, "destroy", gtk_main_quit, NULL);
//salir
	 quit=GTK_WIDGET(gtk_builder_get_object(builder, "SALIR"));
	 g_signal_connect (quit, "clicked", G_CALLBACK(isClickedquit),NULL);

//credit botton
	 credits=GTK_WIDGET(gtk_builder_get_object(builder, "CREDITOS"));
	 g_signal_connect (credits, "clicked", G_CALLBACK(isClickedcredits),NULL);
//credit ventana
	 w_credits = GTK_WIDGET(gtk_builder_get_object(builder, "PANTCREDITOS"));
	 g_signal_connect (w_credits, "destroy", gtk_main_quit, NULL);
//back_credit
	 backcred=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASCREDITOS"));
	 g_signal_connect (backcred, "clicked", G_CALLBACK(isClickedbackcred),NULL);

//help button
	 rules=GTK_WIDGET(gtk_builder_get_object(builder, "REGLAS"));
	 g_signal_connect (rules, "clicked", G_CALLBACK(isClickedrules),NULL);
//rules ventana
	 w_rules = GTK_WIDGET(gtk_builder_get_object(builder, "PANTREGLAS"));
	 g_signal_connect (w_rules, "destroy", gtk_main_quit, NULL);
//back rules
	 backrules=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASREGLAS"));
	 g_signal_connect (backrules, "clicked", G_CALLBACK(isClickedbackrules),NULL);

//play button
	 players=GTK_WIDGET(gtk_builder_get_object(builder, "JUGAR"));
	 g_signal_connect (players, "clicked", G_CALLBACK(isClickedplay),NULL);
//play ventana
	 w_play = GTK_WIDGET(gtk_builder_get_object(builder, "PANTJUG"));
	 g_signal_connect (w_play, "destroy", gtk_main_quit, NULL);
//back play
	 backplay=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASJUGADORES"));
	 g_signal_connect (backplay, "clicked", G_CALLBACK(isClickedbackplay),NULL);
//playes button
	 //jugvsjug=GTK_WIDGET(gtk_builder_get_object(builder, "JUGVSJUG"));
	 //g_signal_connect (jugvsjug, "clicked", G_CALLBACK(isClickedpvp),NULL);
	 jugvscomp=GTK_WIDGET(gtk_builder_get_object(builder, "JUGVSCOMP"));
	 g_signal_connect (jugvscomp, "clicked", G_CALLBACK(isClickedpvc),NULL);
	 //compvscomp=GTK_WIDGET(gtk_builder_get_object(builder, "COMPVSCOMP"));
	 //g_signal_connect (compvscomp, "clicked", G_CALLBACK(isClickedcvc),NULL);
//tam ventana
	 w_tam = GTK_WIDGET(gtk_builder_get_object(builder, "PANTTAM"));
	 g_signal_connect (w_tam, "destroy", gtk_main_quit, NULL);
//back play
	 backplayers=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASTAM"));
	 g_signal_connect (backplayers, "clicked", G_CALLBACK(isClickedbackplayers),NULL);
//tam buttons

	/*dim3=GTK_WIDGET(gtk_builder_get_object(builder, "3x3"));
	g_signal_connect (dim3, "clicked", G_CALLBACK(isClickedtam3),NULL);*/

	/*dim4=GTK_WIDGET(gtk_builder_get_object(builder, "4x4"));
	g_signal_connect (dim4, "clicked", G_CALLBACK(isClickedtam4),NULL);

	dim5=GTK_WIDGET(gtk_builder_get_object(builder, "5x5"));
	g_signal_connect (dim5, "clicked", G_CALLBACK(isClickedtam5),NULL);

	dim6=GTK_WIDGET(gtk_builder_get_object(builder, "6x6"));
	g_signal_connect (dim6, "clicked", G_CALLBACK(isClickedtam6),NULL);

	dim7=GTK_WIDGET(gtk_builder_get_object(builder, "7x7"));
	g_signal_connect (dim7, "clicked", G_CALLBACK(isClickedtam7),NULL);

	dim8=GTK_WIDGET(gtk_builder_get_object(builder, "8x8"));
	g_signal_connect (dim8, "clicked", G_CALLBACK(isClickedtam8),NULL);

	dim9=GTK_WIDGET(gtk_builder_get_object(builder, "9x9"));
	g_signal_connect (dim9, "clicked", G_CALLBACK(isClickedtam9),NULL);

	dim10=GTK_WIDGET(gtk_builder_get_object(builder, "10x10"));
	g_signal_connect (dim10, "clicked", G_CALLBACK(isClickedtam10),NULL);

	dim11=GTK_WIDGET(gtk_builder_get_object(builder, "11x11"));
	g_signal_connect (dim11, "clicked", G_CALLBACK(isClickedtam11),NULL);

	dim12=GTK_WIDGET(gtk_builder_get_object(builder, "12x12"));
	g_signal_connect (dim12, "clicked", G_CALLBACK(isClickedtam12),NULL);

	dim13=GTK_WIDGET(gtk_builder_get_object(builder, "13x3"));
	g_signal_connect (dim13, "clicked", G_CALLBACK(isClickedtam13),NULL);

	dim14=GTK_WIDGET(gtk_builder_get_object(builder, "14x14"));
	g_signal_connect (dim14, "clicked", G_CALLBACK(isClickedtam14),NULL);

	dim15=GTK_WIDGET(gtk_builder_get_object(builder, "15x15"));
	g_signal_connect (dim15, "clicked", G_CALLBACK(isClickedtam15),NULL);

	dimr=GTK_WIDGET(gtk_builder_get_object(builder, "RANDOM"));
	g_signal_connect (dimr, "clicked", G_CALLBACK(isClickedtamR),NULL);*/

//nombres ventana
	 w_nom= GTK_WIDGET(gtk_builder_get_object(builder, "PANTNOM"));
	 g_signal_connect (w_nom, "destroy", gtk_main_quit, NULL);
//back tam
	 backtam=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASNOM"));
	 g_signal_connect (backtam, "clicked", G_CALLBACK(isClickedbacktam),NULL);
//aceptar buttons
	 aceptar=GTK_WIDGET(gtk_builder_get_object(builder, "ACEPTAR"));
	 g_signal_connect (aceptar, "clicked", G_CALLBACK(isClickedturno),NULL);
//aceptar size
	 aceptar1=GTK_WIDGET(gtk_builder_get_object(builder, "ACEPTAR1"));
	 g_signal_connect (aceptar1, "clicked", G_CALLBACK(matrixSize),NULL);
//back nom
	 backnom=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASNOM"));
	 //entry1=GTK_WIDGET(gtk_builder_get_object(builder, "entry1"));
	 g_signal_connect (backnom, "clicked", G_CALLBACK(isClickedbacktam),NULL);
//turno ventana
	 w_turn= GTK_WIDGET(gtk_builder_get_object(builder, "PANTTURNO"));
	 g_signal_connect (w_turn, "destroy", gtk_main_quit, NULL);
//back turno
	 backturno=GTK_WIDGET(gtk_builder_get_object(builder, "ATRASTURNO"));
	 g_signal_connect (backturno, "clicked", G_CALLBACK(isClickedbackturno),NULL);
//turno
	 EMP1=GTK_WIDGET(gtk_builder_get_object(builder, "JUGADOR1TURNO"));
	 g_signal_connect (EMP1, "clicked", G_CALLBACK(isClickedturno1),NULL);
	 EMP2=GTK_WIDGET(gtk_builder_get_object(builder, "JUGADOR2TURNO"));
	 g_signal_connect (EMP2, "clicked", G_CALLBACK(isClickedturno2),NULL);
	 EMP3=GTK_WIDGET(gtk_builder_get_object(builder, "ALEATORIOTURNO"));
	 g_signal_connect (EMP3, "clicked", G_CALLBACK(isClickedturno3),NULL);
//partida ventana
	w_jugar= GTK_WIDGET(gtk_builder_get_object(builder, "PANTPARTIDA"));
	g_signal_connect (w_jugar, "destroy", gtk_main_quit, NULL);
//LABEL
	Jugador1 = GTK_LABEL(gtk_builder_get_object(builder, "SCORE1"));
	Jugador2 = GTK_LABEL(gtk_builder_get_object(builder, "SCORE2"));
	CONTMOV = GTK_LABEL(gtk_builder_get_object(builder, "CONTROLMOV"));
//ENDING
	 w_end = GTK_WIDGET(gtk_builder_get_object(builder, "ENDING"));
	 g_signal_connect (w_end, "destroy", gtk_main_quit, NULL);
	 DESP = GTK_LABEL(gtk_builder_get_object(builder, "GANADOR"));
	 MainMenu=GTK_WIDGET(gtk_builder_get_object(builder, "RETURN"));
	 g_signal_connect (MainMenu, "clicked", G_CALLBACK(isClickedmainmenu),NULL);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Ventana TABLERO
	CantJogadas();
	w_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "PANTGAME"));

	//Box donde estara el Tablero
	box_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "box_tablero"));

	//Labels
	//label_turno = GTK_WIDGET(gtk_builder_get_object(builder, "label_turno"));
	//label_estado = GTK_WIDGET(gtk_builder_get_object(builder, "label_estado"));

	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);


	/* Connect the destroy signal of the window to gtk_main_quit
	* When the window is about to be destroyed we get a notification and
	* stop the main GTK+ loop
	*/
	gtk_widget_show_all (w_main);
	gtk_main ();

    return 1;
 }


