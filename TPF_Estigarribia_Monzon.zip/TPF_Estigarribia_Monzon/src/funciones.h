/*
 * funciones.h
 *
 *  Created on: 28 oct. 2021
 *      Author: lp1-2021
 */

#ifndef FUNCIONES_H_
#define FUNCIONES_H_
#include "tableros.c"
#define TAM_REAL 13
#define SIZE 10


//Un vector de Strings, almacena ubicacion de imagenes
//PRIMERA IMAGEN PUNTO//SEGUNDA IMAGEN ESPACIO//TERCERA IMAGEN BARRA HORIZONTAL//CUARTA IMAGEN BARRA VERTICAL
char *imagenes[] = {"./IMG/dot.png","./IMG/BLANCO.png"};
char *naranja[] = {"./IMG/horizontal_naranja.png","./IMG/vertical_naranja.png","./IMG/JUGADOR_NARANJA.png"};
char *azul[] = {"./IMG/horizontal_azul.png","./IMG/vertical_azul.png","./IMG/JUGADOR_AZUL.png"};
char inputam[SIZE];
gchar MATRIXSZ;
int cantjug;
int tamjug;
int start;
int cont=0;
int Jogadas=0;
int T=0;
int Msize=3;//tamanho de la matriz
//int **board;
int board[TAM_REAL][TAM_REAL];
int User=0;
int Comp=0;
int repetir,Player;
int seguro;

//int *tablero_de_tableros[12];

//GtkWidget *label_turno;
//GtkWidget *label_estado;
GtkWidget *tablero;
//ventana tablero
GtkWidget *w_tablero;
GtkWidget *box_tablero;
//main wind
GtkWidget *w_main;
GtkWidget *quit;
//play wind
GtkWidget *w_play;
GtkWidget *players;
GtkWidget *backplay;
//credit wind
GtkWidget *w_credits;
GtkWidget *credits;
GtkWidget *backcred;
//help wind
GtkWidget *w_rules;
GtkWidget *rules;
GtkWidget *backrules;
//PLAYERS
GtkWidget *jugvsjug;
GtkWidget *jugvscomp;
GtkWidget *compvscomp;
GtkWidget *backplayers;
//Tam
GtkWidget *w_tam;


GtkWidget *backtam;
//nom
GtkWidget *w_nom;
GtkWidget *aceptar;
GtkWidget *aceptar1;
GtkWidget *backnom;
//turno
GtkWidget *w_turn;
GtkWidget *EMP1;
GtkWidget *EMP2;
GtkWidget *EMP3;
GtkWidget *backturno;
//
GtkWidget *w_jugar;
GtkWidget *entry1;
GtkWidget *entrysize;
GtkWidget *nom2;
//labels
GtkWidget *CONTMOV;
GtkWidget *Jugador1;
GtkWidget *Jugador2;
//ENDING
GtkWidget *w_end;
GtkWidget *MainMenu;
GtkWidget *DESP;

////////////////////////////
GtkWidget *crear_tablero();
void CreateBoard();
void chequeo(int i,int j);

#endif /* FUNCIONES_H_ */
